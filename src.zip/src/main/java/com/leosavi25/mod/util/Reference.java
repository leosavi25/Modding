package com.leosavi25.mod.util;

public class Reference {

	public static final String MOD_ID = "factorycraft";
	public static final String VERSION = "1.0";
	public static final String NAME = "FactoryCraft";
	
	public static final String CLIENT_PROXY = "com.leosavi25.mod.proxy.ClientProxy";
	public static final String COMMON_PROXY = "com.leosavi25.mod.proxy.CommonProxy";
}
