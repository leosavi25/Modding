package com.leosavi25.mod.util.interfaces;

public interface IHasModel {

	public void registerModels();
}
